(function(){
  'use strict';

  const el = (id)=>document.getElementById(id);
  const state = {
    communes: [],
    selected: null,
    geo: { commune:'', insee:'', dep:'', depName:'', reg:'', regName:'', epci:'' }
  };

  function sanitizeCp(v){
    return String(v||'').replace(/\D/g,'').slice(0,5);
  }

  function setCpStatus(msg, isError){
    const s = el('cpStatus');
    s.textContent = msg || '';
    s.style.color = isError ? '#8a1f1f' : '';
  }

  function renderGeoSummary(){
    const parts = [];
    if(state.geo.commune) parts.push(`Commune: ${state.geo.commune}`);
    if(state.geo.depName || state.geo.dep) parts.push(`Département: ${state.geo.depName ? state.geo.depName + ' (' + state.geo.dep + ')' : state.geo.dep}`);
    if(state.geo.regName || state.geo.reg) parts.push(`Région: ${state.geo.regName ? state.geo.regName + ' (' + state.geo.reg + ')' : state.geo.reg}`);
    if(state.geo.epci) parts.push(`EPCI: ${state.geo.epci}`);

    const box = el('geoSummary');
    const txt = el('geoText');
    if(!parts.length){
      box.hidden = true;
      txt.textContent = '';
      return;
    }
    box.hidden = false;
    txt.innerHTML = parts.map(p=>`<div>${escapeHtml(p)}</div>`).join('');
  }

  function escapeHtml(s){
    return String(s||'')
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#039;');
  }

  function applySelectedCommune(idx){
    const c = state.communes[idx];
    if(!c) return;
    state.selected = c;
    state.geo.commune = c.nom || '';
    state.geo.insee = c.code || '';
    state.geo.dep = (c.departement && c.departement.code) ? c.departement.code : '';
    state.geo.depName = (c.departement && c.departement.nom) ? c.departement.nom : '';
    state.geo.reg = (c.region && c.region.code) ? c.region.code : '';
    state.geo.regName = (c.region && c.region.nom) ? c.region.nom : '';
    state.geo.epci = (c.epci && c.epci.nom) ? c.epci.nom : '';
    renderGeoSummary();
  }

  async function fetchCommunes(cp){
    // Official: geo.api.gouv.fr
    const url = `https://geo.api.gouv.fr/communes?codePostal=${encodeURIComponent(cp)}&fields=nom,code,departement,region,epci&format=json`;
    setCpStatus('Zoeken…', false);

    try{
      const r = await fetch(url, { method:'GET' });
      if(!r.ok) throw new Error(`HTTP ${r.status}`);
      const data = await r.json();
      if(!Array.isArray(data) || !data.length){
        state.communes = [];
        state.selected = null;
        el('communeWrap').hidden = true;
        renderGeoSummary();
        setCpStatus('Geen commune gevonden voor deze postcode. Controleer de 5 cijfers.', true);
        return;
      }

      state.communes = data;
      const sel = el('commune');
      sel.innerHTML = '';
      data.forEach((c,i)=>{
        const opt = document.createElement('option');
        opt.value = String(i);
        opt.textContent = `${c.nom} (INSEE ${c.code})`;
        sel.appendChild(opt);
      });

      el('communeWrap').hidden = (data.length <= 1);
      sel.value = '0';
      applySelectedCommune(0);
      setCpStatus(data.length > 1 ? 'Meerdere communes bij deze postcode: kies hieronder.' : 'Commune gevonden.', false);
    }catch(e){
      state.communes = [];
      state.selected = null;
      el('communeWrap').hidden = true;
      renderGeoSummary();
      setCpStatus('Postcode-lookup mislukt (API tijdelijk onbereikbaar). Gebruik direct het France Rénov’-loket.', true);
    }
  }

  function badge(color, label){
    return `<span class="badge ${color}">${escapeHtml(label)}</span>`;
  }

  function linkBtn(href, label, primary){
    const cls = primary ? 'btn primary' : 'btn';
    return `<a class="${cls}" href="${href}" target="_blank" rel="noopener noreferrer">${escapeHtml(label)}</a>`;
  }

  function card(title, badgeHtml, bodyHtml, linksHtml){
    return `
      <div class="rule">
        <div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
          <div style="flex:1;min-width:220px;font-weight:900;color:var(--maroon);">${escapeHtml(title)}</div>
          <div>${badgeHtml}</div>
        </div>
        <div style="margin-top:8px;">${bodyHtml}</div>
        ${linksHtml ? `<div class="row wrap" style="margin-top:10px;">${linksHtml}</div>` : ''}
      </div>
    `;
  }

  function compute(){
    const usage = el('usage').value;
    const age = el('age').value;
    const stage = el('stage').value;
    const work = el('work').value;
    const heatloss = el('heatloss').value;
    const mprPath = el('mprPath').value;

    const isBeforeSignature = (stage === 'before' || stage === 'quotes');
    const isSignedOrStarted = (stage === 'signed' || stage === 'started');
    const isStarted = (stage === 'started');
    const isRp = (usage === 'rp');
    const isRent = (usage === 'rent');

    // MaPrimeRénov’ (timing)
    let mprColor='green', mprLabel='Kansrijk (pre-check)';
    const mprWhy=[];
    if(isStarted){
      mprColor='red'; mprLabel='Risico: vaak te laat';
      mprWhy.push('Werk is gestart: bij MaPrimeRénov’ hoort uitvoering pas na acceptatie van de aanvraag.');
    }else if(isSignedOrStarted){
      mprColor='amber'; mprLabel='Check nodig';
      mprWhy.push('Devis is getekend: laat door het loket bevestigen of dit gevolgen heeft; uitvoering hoort pas na acceptatie.');
    }else{
      mprWhy.push('U zit vóór start: dit is de juiste volgorde (dossier → acceptatie → uitvoering).');
    }
    if(usage === 'second'){
      if(mprColor==='green'){ mprColor='amber'; mprLabel='Check nodig'; }
      mprWhy.push('Tweede woning: voorwaarden kunnen afwijken; laat dit bevestigen via het loket.');
    }
    if(mprPath==='ampleur'){
      mprWhy.push('Rénovation d’ampleur: doorgaans begeleiding (Mon Accompagnateur Rénov’) en strakkere spelregels.');
    }

    // CEE (timing + 2-year typical)
    let ceeColor='green', ceeLabel='Kansrijk (pre-check)';
    const ceeWhy=[];
    if(!isBeforeSignature){
      ceeColor='red'; ceeLabel='Blokkade-risico';
      ceeWhy.push('CEE vraagt doorgaans inschrijving/aanvraag vóór ondertekenen van het devis. Als u al tekende, kan het te laat zijn.');
    }else{
      ceeWhy.push('U zit vóór ondertekenen: dit past bij CEE (eerst inschrijven/akkoord, dan pas devis).');
    }
    if(age==='no'){
      ceeColor='red'; ceeLabel='Niet passend';
      ceeWhy.push('CEE geldt doorgaans voor woningen die >2 jaar geleden zijn opgeleverd.');
    }
    if(work==='unknown'){
      if(ceeColor==='green'){ ceeColor='amber'; ceeLabel='Check nodig'; }
      ceeWhy.push('Type werk onzeker: CEE hangt af van standaardoperaties/werksoort. Laat dit bevestigen.');
    }

    // Éco-PTZ (RP + >2y)
    let ptzColor='green', ptzLabel='Kansrijk (pre-check)';
    const ptzWhy=[];
    if(!isRp){
      ptzColor='red'; ptzLabel='Niet passend (meestal)';
      ptzWhy.push('Éco-PTZ is gekoppeld aan résidence principale (of bestemd om dat te worden).');
    }else{
      ptzWhy.push('Résidence principale: basisvoorwaarde lijkt aanwezig.');
    }
    if(age==='no'){
      ptzColor='red'; ptzLabel='Niet passend';
      ptzWhy.push('Éco-PTZ vereist doorgaans dat de woning >2 jaar oud is bij start van de werken.');
    }else if(age==='unknown'){
      if(ptzColor==='green'){ ptzColor='amber'; ptzLabel='Check nodig'; }
      ptzWhy.push('Leeftijd woning onbekend: check of het logement >2 jaar oud is.');
    }
    if(isRent && ptzColor!=='red'){
      if(ptzColor==='green'){ ptzColor='amber'; ptzLabel='Check nodig'; }
      ptzWhy.push('Bailleur kan, maar er gelden verhuurverplichtingen/termijnen. Laat dit bevestigen.');
    }

    // TVA 5,5% (2y + eligible works)
    let tvaColor='green', tvaLabel='Kansrijk (pre-check)';
    const tvaWhy=[];
    if(age==='no'){
      tvaColor='red'; tvaLabel='Niet passend';
      tvaWhy.push('TVA à 5,5% geldt doorgaans alleen voor logementen >2 jaar.');
    }else if(age==='unknown'){
      tvaColor='amber'; tvaLabel='Check nodig';
      tvaWhy.push('Leeftijd woning onbekend: de 2-jaargrens is meestal bepalend.');
    }else{
      tvaWhy.push('Woning >2 jaar: basisvoorwaarde lijkt aanwezig.');
    }
    tvaWhy.push('Let op facturatie/scope: 5,5% geldt voor energieprestatie-werken met technische criteria.');
    if(work==='unknown'){
      if(tvaColor==='green'){ tvaColor='amber'; tvaLabel='Check nodig'; }
      tvaWhy.push('Type werk onzeker: laat het tarief bevestigen door de uitvoerder en via France Rénov’/Service-Public.');
    }

    // Local
    const locColor='amber', locLabel='Altijd checken';
    const locWhy=[
      'Lokale regelingen variëren per mairie/EPCI/département/région en wijzigen regelmatig.',
      'Veilige aanpak: routeer altijd via France Rénov’ adviseur + vaste zoekstrategie.'
    ];

    // Render cards
    const cards=[];
    cards.push(card(
      'MaPrimeRénov’',
      badge(mprColor, mprLabel),
      `<ul>${mprWhy.map(x=>`<li>${escapeHtml(x)}</li>`).join('')}</ul>`,
      linkBtn('https://infofrankrijk.com/ma-prime-renov-in-frankrijk-voorwaarden-werking-en-aandachtspunten/','Detailartikel MaPrimeRénov’', false) +
      linkBtn('https://france-renov.gouv.fr/preparer-projet/trouver-conseiller','France Rénov’ loket', true)
    ));

    cards.push(card(
      'CEE / primes énergie',
      badge(ceeColor, ceeLabel),
      `<ul>${ceeWhy.map(x=>`<li>${escapeHtml(x)}</li>`).join('')}</ul>`,
      linkBtn('https://infofrankrijk.com/cee-en-primes-energie-energiebesparingspremies-in-frankrijk-uitgelegd/','Detailartikel CEE', false) +
      linkBtn('https://france-renov.gouv.fr/preparer-projet/trouver-conseiller','Check via France Rénov’', true)
    ));

    cards.push(card(
      'Éco-PTZ (renteloze lening)',
      badge(ptzColor, ptzLabel),
      `<ul>${ptzWhy.map(x=>`<li>${escapeHtml(x)}</li>`).join('')}</ul>`,
      linkBtn('https://infofrankrijk.com/eco-ptz-renteloze-lening-voor-energierenovatie-in-frankrijk/','Detailartikel Éco-PTZ', false) +
      linkBtn('https://france-renov.gouv.fr/preparer-projet/trouver-conseiller','Route via adviseur', true)
    ));

    cards.push(card(
      'TVA à 5,5% (verlaagd btw-tarief)',
      badge(tvaColor, tvaLabel),
      `<ul>${tvaWhy.map(x=>`<li>${escapeHtml(x)}</li>`).join('')}</ul>`,
      linkBtn('https://infofrankrijk.com/tva-a-55-bij-renovatie-in-frankrijk-wanneer-geldt-het-lage-btw-tarief/','Detailartikel TVA 5,5%', false) +
      linkBtn('https://france-renov.gouv.fr/preparer-projet/trouver-conseiller','Controleer voorwaarden', true)
    ));

    cards.push(card(
      'Lokale steun (commune / EPCI / département / région)',
      badge(locColor, locLabel),
      `<ul>${locWhy.map(x=>`<li>${escapeHtml(x)}</li>`).join('')}</ul>`,
      linkBtn('https://infofrankrijk.com/lokale-subsidies-voor-energierenovatie-in-frankrijk-zo-vindt-u-wat-er-geldt/','Zo vindt u lokale steun', false) +
      linkBtn('https://france-renov.gouv.fr/preparer-projet/trouver-conseiller','Loket per postcode', true)
    ));

    el('cards').innerHTML = cards.join('');

    // Combinations
    const warns=[];
    if(mprPath==='ampleur') warns.push('Bij rénovation d’ampleur (parcours accompagné) kan de praktische afhandeling van CEE anders lopen dan bij “par geste”. Start niet dubbel zonder bevestiging.');
    if(!isBeforeSignature) warns.push('Als u al tekende: CEE is vaak te laat. Vermijd “achteraf nog even CEE regelen” zonder bevestiging.');
    if(isStarted) warns.push('Als u al gestart bent: laat meteen beoordelen welke sporen nog open staan.');

    el('combo').innerHTML = `
      <div class="summaryTitle">Hoofdregel</div>
      <p>Combineren kan vaak, maar het gaat vooral mis op <strong>timing</strong>, <strong>uitvoerder-eisen</strong> en <strong>bewijsstukken</strong>.</p>
      <div class="summaryTitle" style="margin-top:10px;">Meestal probleemloos</div>
      <ul>
        <li><strong>MaPrimeRénov’ + éco-PTZ</strong> (subsidie + financiering)</li>
        <li><strong>MaPrimeRénov’ + TVA 5,5%</strong> (subsidie + btw-tarief)</li>
        <li><strong>CEE + TVA 5,5%</strong> (premie + btw-tarief)</li>
        <li><strong>MaPrimeRénov’ + lokale hulp</strong> (kan, maar lokaal heeft eigen deadlines)</li>
      </ul>
      <div class="summaryTitle" style="margin-top:10px;">Waar het misgaat</div>
      ${warns.length ? `<ul>${warns.map(x=>`<li>${escapeHtml(x)}</li>`).join('')}</ul>` : `<p class="muted small">U zit nog in de veilige fase (vóór tekenen/start). Houd dat vast totdat loket/voorwaarden bevestigd zijn.</p>`}
    `;

    // Local
    const geoLines=[];
    if(state.geo.commune) geoLines.push(`<div><strong>Commune:</strong> ${escapeHtml(state.geo.commune)}</div>`);
    if(state.geo.epci) geoLines.push(`<div><strong>EPCI:</strong> ${escapeHtml(state.geo.epci)}</div>`);
    if(state.geo.depName || state.geo.dep) geoLines.push(`<div><strong>Département:</strong> ${escapeHtml(state.geo.depName ? state.geo.depName + ' (' + state.geo.dep + ')' : state.geo.dep)}</div>`);
    if(state.geo.regName || state.geo.reg) geoLines.push(`<div><strong>Région:</strong> ${escapeHtml(state.geo.regName ? state.geo.regName + ' (' + state.geo.reg + ')' : state.geo.reg)}</div>`);

    const local = el('local');
    local.innerHTML = `
      ${geoLines.length ? `<div class="summary">${geoLines.join('')}</div>` : `<div class="muted">Vul een postcode in om de bestuurslagen te tonen.</div>`}
      <div>Vraag bij uw <strong>mairie</strong> en/of <strong>EPCI</strong> of er een lokaal renovatieprogramma loopt. Verifieer via <strong>France Rénov’</strong>.</div>
      <div class="row wrap">
        ${linkBtn('https://france-renov.gouv.fr/preparer-projet/trouver-conseiller','France Rénov’ adviseur', true)}
        ${linkBtn('https://france-renov.gouv.fr/aides/collectivites-locales','Aides locales (France Rénov’)', false)}
      </div>
    `;

    // Plan
    const lines=[];
    const today = new Date();
    lines.push(`SUBSIDIE-ROUTE (indicatief) — ${today.toLocaleDateString('nl-NL')}`);
    if(state.geo.commune) lines.push(`Locatie: ${state.geo.commune}${state.geo.dep ? ' ('+state.geo.dep+')' : ''}`);
    lines.push('');
    lines.push('0) Timing (kritiek):');
    if(isStarted) lines.push('- U bent gestart: laat direct beoordelen welke sporen nog open staan (France Rénov’).');
    else if(isSignedOrStarted) lines.push('- U heeft getekend: CEE is vaak te laat; MPR: start pas na acceptatie en laat dossier checken.');
    else lines.push('- U zit vóór tekenen/start: houd dit zo totdat loket en voorwaarden bevestigd zijn.');
    lines.push('');
    lines.push(`1) MPR-traject: ${mprPath==='ampleur' ? 'Rénovation d\'ampleur (parcours accompagné)' : (mprPath==='geste' ? 'Par geste' : 'Onzeker')}`);
    lines.push('2) Combinaties: kunnen vaak, maar bevestig bij loket (timing/bewijsstukken/uitvoerder-eisen).');
    lines.push('');
    lines.push('3) Links:');
    lines.push('- France Rénov’ adviseur: https://france-renov.gouv.fr/preparer-projet/trouver-conseiller');
    lines.push('- MaPrimeRénov’: https://infofrankrijk.com/ma-prime-renov-in-frankrijk-voorwaarden-werking-en-aandachtspunten/');
    lines.push('- CEE: https://infofrankrijk.com/cee-en-primes-energie-energiebesparingspremies-in-frankrijk-uitgelegd/');
    lines.push('- Éco-PTZ: https://infofrankrijk.com/eco-ptz-renteloze-lening-voor-energierenovatie-in-frankrijk/');
    lines.push('- TVA 5,5%: https://infofrankrijk.com/tva-a-55-bij-renovatie-in-frankrijk-wanneer-geldt-het-lage-btw-tarief/');
    lines.push('- Lokale zoekstrategie: https://infofrankrijk.com/lokale-subsidies-voor-energierenovatie-in-frankrijk-zo-vindt-u-wat-er-geldt/');
    el('plan').value = lines.join('\n');

    // Results visible
    el('results').hidden = false;
    el('results').scrollIntoView({behavior:'smooth', block:'start'});

    // Heatloss reminder (non-blocking)
    if(heatloss === 'no'){
      // no popup; keep it calm and practical.
    }
  }

  function init(){
    const btnLookup = el('btnLookup');
    const btnCalc = el('btnCalc');
    const btnCopy = el('btnCopy');

    btnLookup.addEventListener('click', ()=>{
      const cp = sanitizeCp(el('cp').value);
      el('cp').value = cp;
      if(cp.length !== 5){ setCpStatus('Vul een postcode met 5 cijfers in.', true); return; }
      fetchCommunes(cp);
    });

    el('cp').addEventListener('keydown', (e)=>{
      if(e.key === 'Enter'){
        e.preventDefault();
        btnLookup.click();
      }
    });

    el('commune').addEventListener('change', ()=>{
      const idx = Number(el('commune').value);
      applySelectedCommune(Number.isFinite(idx) ? idx : 0);
    });

    btnCalc.addEventListener('click', compute);

    btnCopy.addEventListener('click', async ()=>{
      const t = el('plan').value || '';
      el('copyStatus').textContent = '';
      if(!t) return;
      try{
        await navigator.clipboard.writeText(t);
        el('copyStatus').textContent = 'Gekopieerd.';
      }catch(_){
        el('copyStatus').textContent = 'Kopiëren lukt niet automatisch; selecteer de tekst handmatig.';
      }
    });
  }

  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();
